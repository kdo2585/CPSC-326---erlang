%Daniel Gallab and Kevin Du
%Final Project
%Search engine by keys and values in Erlang


-module(searchEngine).
	-export([tokenize/1]).
        -export([inputKV/0]).
	-export([createKV/2]).
	-export([createmap/0]).
	-export([comment_relevance/2]).
	-export([comment_length/1]).
	-export([add_comment_data/3]).
	-export([start/0]).
	-export([sort/1]).
	-export([store_comments/2]).
	-export([read/1]).
	-export([tuples_to_list/1]).
		

	%sorts based on a specified value
		sort(Rank)-> 
			lists:keysort(3,[Rank]).
	
	%turns a string into a list of words	
		tokenize(String) ->
			string:tokens(String, " ").

	%takes a string of words and values
		inputKV()-> 
			 tokenize( io:get_line("Enter keywords and values(1-6), separated by spaces: ")).

	%recursive function which creates a map of keys and values given a string. Assumes user will input an even number of strings
	%and values
	
	%base case
		createKV([],Map) -> 
			Map;

	%recursive case
	        createKV(List, Map)-> 
			Map1=  #{lists:nth(1,List) =>element(1,string:to_integer(lists:nth(1,lists:nthtail(1,List))))}, 
			Map2 = maps:merge(Map1,Map), 
			createKV(lists:nthtail(2,List), Map2) .
	
		createmap()->
			createKV(inputKV(),	#{}).

	%searches through string using recursion and if a keyword is found, the corresponding value is added

		comment_relevance([],Map)-> 0;
	
		comment_relevance(List,Map)-> 
			io:fwrite("~p~n",[List]),
			case maps:is_key(lists:nth(1,List),Map) of 
				true -> element(2,maps:find(lists:nth(1,List),Map)) + comment_relevance(lists:nthtail(1,List),Map); 
				false->comment_relevance(lists:nthtail(1,List),Map)
			end.
		

		comment_length(String)-> length(tokenize(String)).
	
	%creates a tuple with string, relevance score, length, and score divided by length	
		add_comment_data(Id,R,L)-> [{Id,R,L, R/L}].
	
	%reads text file (which holds the comments)	
		read(File) ->
				{ok,Binary} = file:read_file(File),
				Lines = string:tokens(erlang:binary_to_list(Binary),"\n").
 
	
	%makes a list of tuples

		store_comments([],Map)->
				[];
		
		store_comments(ComLists, Map)->
			Id = lists:nth(1,ComLists), 
			List=tokenize(Id),
			R=comment_relevance(List, Map), io:fwrite("~p~n",[R]),
			L=comment_length(List),
			lists:append(add_comment_data(Id,R,L), store_comments(lists:nthtail(1,ComLists),Map)).
		
	%creates a list from tuples by comparing strings
		tuples_to_list([])->[];

		tuples_to_list(Tl)->  lists:append([element(1,lists:nth(1,Tl))], tuples_to_list(lists:nthtail(1,Tl))).
		
		
		
		start()->
			R= read(test),
			M=createmap(),
			S = store_comments(R, M),

	%asks user how he/she wants to sort
			G = io:get_line("How do you want to sort? (L = length, R= relevance, D=density)"),
			if
				G == "L\n" ->
					X = 3;
				G == "R\n" ->
					X = 2;
				G== "D\n"->
					X = 4
			end,

			B = lists:keysort(X,S),
	%sorts from highest to lowest or lowest to highest		
			N = io:get_line("Do you want to sort in reverse? (y,n)"),			
			if
				N == "y\n" ->
					Z =  lists:reverse(B);
				N== "n\n" ->
					Z=B
			end,

	%writes sorted comments to a file
			Sc=tuples_to_list(Z),
    			Print = string:join(Sc, "\n\n"),
    			file:write_file(sortedcomments, Print).
